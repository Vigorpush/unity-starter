﻿using UnityEngine;
using System.Collections;

public class spawnrate : MonoBehaviour {


	//Highest difficulty
	public int top_diffic_rate = 3; 
	//current difficulty, and can be accessed by other class
	public static int curr_spawn_rate = 1;

	private bool checkstate = true;

	// Update is called once per frame
	void Start () {
		InvokeRepeating ("evolveEnemy", 0, 5);
	}


	void evolveEnemy(){
		if (curr_spawn_rate < top_diffic_rate) {
			curr_spawn_rate++;
		} else {
			//reached the highest difficulty
			CancelInvoke ("evolveEnemy");
		}
	}
}
