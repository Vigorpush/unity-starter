﻿using UnityEngine;
using System.Collections;

public class AI : MonoBehaviour {

    //AI Enermy
    public GameObject en;//get the gameobject

    //ATTACK()
	public Transform target;
	public float speed;
    private Transform mytransform;

    //MOVETOSPAWN()
    public Transform Spawnpoint;//spwan position
    public float enermy_spawn_distance = 20f;//minimum distance with enermy

    //RANDOMWALK()
    private float originalx;//origin x position
    public float floatStrendth = 1;

    //RETREAT()
    public float distance = 10f;//distance bewteen player and the enermy
    public float runalwaysspeed = 10f;//running speed 

    //ADVANCE()
    private bool isadvanced = false;
    ParticleSystem ps;
    public float advanceed = 5f;

    //IDLEANITION()
    public Animator ani;
    const int STATE_IDE = 1;
    const int STATE_WALKING = 0;
    int _currentAnimationState = STATE_WALKING;
    public float idletime = 5f;
    /*
    const int RANDOMWALK = 0;
    const int ATTACK = 1;
    const int MOVETOSPAWN = 2;
    const int ADVANCE = 3;
    const int RETREAT = 4;
    const int IDLEANITION = 6;

    public int _CURRENTSTATE = 0;
    */

    float[] distancefriend;//find the friends
    public float nearcheck = 5;


    public float Maxdistancetohome = 20;
    public Transform home;//the home location


    public float maxrangetoplayer = 20;
    public float maxThreatzone = 100;

    private enemy en2;
	void Start () {
        mytransform = transform;
        //mytransform.position = new Vector3(2, 0, 2);
        en = GetComponent<GameObject>();//enermy gameoject

        ani = GetComponent<Animator>();//get the 
        originalx = en.transform.position.x;



        GameObject pl = GameObject.FindGameObjectWithTag("Player"); //alocated to player
		target = pl.transform;

        GameObject spawnobject = GameObject.Find("SpawnPoint1");//alocated to spawn location
        Spawnpoint = spawnobject.transform;

        home = gameObject.transform;
	}


	void Update () {
        //RANDOMWALK();
        //ATTACK();
        //MOVETOSPAWN();
        //ADVANCE();
        //RETREAT();
        //IDLEANITION();
        if (checkThreatzone())
        {
            if (checkplayerinrange())
            {
                if (checkedfirend())
                {
                    //ATTACK
                    ATTACK();
                }
                else
                {
                    if (lowHP())
                    {
                        //RETREAT
                        RETREAT();
                    }
                    else
                    {
                        //ATTACK
                        ATTACK();
                    }
                }
            }
            else
            {
                if (lowHP())
                {
                    //RETREAT
                    RETREAT();
                }
                else
                {
                    //ADVANCE
                    ADVANCE();
                }
            }
        }
        else
        {
            if (checkspawn())
            {
                //MOVETOSPAWN
                MOVETOSPAWN();
            }
            else
            {
                if (random())
                {
                    //RANDOM'WALK
                    RANDOMWALK();
                }

                //IDLE'ANIMATION
                IDLEANITION();
            }
        }
	}

    public void ATTACK()
    {
        Vector3 pos = transform.position;
        pos.x = Mathf.MoveTowards(pos.x, target.position.x, Time.deltaTime * speed);
        pos.y = Mathf.MoveTowards(pos.y, target.position.y, Time.deltaTime * speed);
        transform.position = pos;
    }

    public void MOVETOSPAWN()
    {
        Vector3 pos = transform.position;
        pos.x = Mathf.MoveTowards(pos.x, Spawnpoint.position.x, Time.deltaTime * speed);
        pos.y = Mathf.MoveTowards(pos.y, Spawnpoint.position.y, Time.deltaTime * speed);
        transform.position = pos;
    }

    public void IDLEANITION()
    {
        
        ani.SetTrigger("idle");
        _currentAnimationState = STATE_IDE;
    }

    public void RANDOMWALK()
    {
        transform.position = new Vector2(originalx + (Mathf.Cos(Time.time)),transform.position.y);

    }

    public void ADVANCE()
    {
        if (!isadvanced)
        {
            isadvanced = true;
            ps = GetComponent<ParticleSystem>();
            var em = ps.emission;
            em.enabled = true;

            em.type = ParticleSystemEmissionType.Time;

            em.SetBursts(
                new ParticleSystem.Burst[]{
                    new ParticleSystem.Burst(2.0f, 100),
                    new ParticleSystem.Burst(4.0f, 100)
                });
            }
        else
        {
            isadvanced = true;
        }
        Invoke("stopadvanced", advanceed);
    }

    public void RETREAT()
    {
        if (Vector3.Distance(target.position, mytransform.position) < distance)//check the distance between
        {
            //Debug.Log("test");
            Vector3 direction = mytransform.position - target.position;
            direction.Normalize();
            mytransform.position = Vector3.MoveTowards(mytransform.position, direction*distance, Time.deltaTime * runalwaysspeed);
        }
    }

    public void stopadvanced()
    {
        isadvanced = false;
        var em = ps.emission;
        em.enabled = false;
    }


    public void stopidle()
    {
        Debug.Log("test");
        ani.SetTrigger("emoji");
        _currentAnimationState = STATE_WALKING;
    }

    //
    GameObject getfirend()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("Enemy");
        GameObject cloest = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                cloest = go;
                distance = curDistance;
            }
        }

        return cloest;
    }


    float getfirenddistance()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("Enemy");
        GameObject cloest = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                cloest = go;
                distance = curDistance;
            }
        }

        return distance;
    }

    public bool checkedfirend()
    {
        if (getfirenddistance() <= nearcheck)
        {
            return true;
        }
        return false;
    }

    public GameObject[] findEnermy()
    {
        return GameObject.FindGameObjectsWithTag("Enemy");//return all object which name is enermy
    }

    public int countenemy()
    {
        return GameObject.FindGameObjectsWithTag("Enemy").Length;
    }

    public bool checkspawn()
    {
        if (Vector3.Distance(gameObject.transform.position, home.position) < Maxdistancetohome)
        {
            return true;
        }
        return false;

    }



    public Transform gethome()
    {
        return home;
    }

    public GameObject getplayer()
    {
        return GameObject.FindGameObjectWithTag("Player");
    }

    public bool checkplayerinrange()
    {

        if (Vector3.Distance(gameObject.transform.position, getplayer().transform.position) < maxrangetoplayer)
        {
            return true;
        }
        return false;
    }


    public bool checkThreatzone()
    {
        if (Vector3.Distance(gameObject.transform.position, getplayer().transform.position) < maxThreatzone)
        {
            return true;
        }
        return false;
    }


    public bool random()
    {
        int i = Random.Range(1,7);
        if(i%2==0){
            return true;
        }
        return false;
    }


    public bool lowHP()
    {
        if (enemy.currentHealth < 80)
        {
            Debug.Log("low");
            enemy.islowHP = true;
            return enemy.islowHP;
        }
        else
        {
            enemy.islowHP = false;
            return enemy.islowHP;
        }
    }
}
