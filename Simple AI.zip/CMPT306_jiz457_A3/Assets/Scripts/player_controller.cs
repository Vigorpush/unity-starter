﻿using UnityEngine;
using System.Collections;

public class player_controller : MonoBehaviour
{
	public GameObject player;
	public Animator ani;
	public float movespeed;


	const int STATE_IDE = 0;
	const int STATE_WALKING = 1;
	const int STATE_SHOOT = 2;

	int _currentAnimationState = STATE_IDE;
	public GameObject shot;
	public Transform shotSpawn;

	private float nextFire = 0.0F;
	public float fireRate = 1f;
	public AudioClip shotSound;
	public AudioSource audio;

	void Awake(){
	
		audio = GetComponent <AudioSource> ();
	
	}

	void Update(){
		if (Input.GetKeyDown (KeyCode.Space) && Time.time > nextFire) {
			nextFire = Time.time + fireRate;
			audio.PlayOneShot (shotSound,1f);
			Instantiate (shot, shotSpawn.position, shotSpawn.rotation);
		}
	}

	void FixedUpdate ()
	{
		transform.Translate (Input.GetAxis ("Horizontal") * Time.deltaTime * movespeed, Input.GetAxis ("Vertical") * Time.deltaTime * movespeed, 0f);
		if (Input.GetKeyDown ("up") || Input.GetKeyDown ("down") || Input.GetKeyDown ("right") || Input.GetKeyDown ("left")) {
			//Debug.Log ("checked 1");
			changeState (STATE_WALKING);
		} else if (Input.GetKeyDown (KeyCode.Space)) {
			//Debug.Log ("checked 2");
			changeState (STATE_SHOOT);
		}
		else {
			changeState (STATE_IDE);
		}
	}

	private bool CheckWalking ()
	{
		if (Input.GetKeyDown ("up") || Input.GetKeyDown ("down") || Input.GetKeyDown ("right") || Input.GetKeyDown ("left")) {
			
			return true;
		}
		return false;
	}


	private bool CheckShoot (){
		if (Input.GetKeyDown (KeyCode.Space)) {
			return true;
		} 
		return false;
	}

	void changeState (int state)
	{
		if (_currentAnimationState == state) {
			return;
		}

			ani.SetInteger ("state", state);

		_currentAnimationState = state;
	}


}
