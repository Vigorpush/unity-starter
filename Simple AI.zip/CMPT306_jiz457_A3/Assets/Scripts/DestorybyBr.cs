﻿using UnityEngine;
using System.Collections;

public class DestorybyBr : MonoBehaviour {
	public AudioClip shotSound;
	public AudioSource audio;
	public GameObject explosion;

	void Awake(){
		audio = GetComponent <AudioSource> ();
	}

	void OnTriggerExit(Collider other){
		
		if (other.tag == "shot") {
			//Debug.Log ("bullet reach the Bandery!");
			Instantiate (explosion, other.transform.position, other.transform.rotation);
			audio.PlayOneShot (shotSound, 1f);
			Destroy (other.gameObject);

		} 
		if (other.tag =="Player")
		{
			//Debug.Log ("Player reach the Bandery! Start game again");
			Application.LoadLevel ("Main");
		}
	}
}
