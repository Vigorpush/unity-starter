﻿using UnityEngine;
using System.Collections;

public class Shoot : MonoBehaviour {
	private Rigidbody rb;
	public float speed;
	void Start(){
		rb = GetComponent<Rigidbody> ();
	}
	void Update(){
		rb.velocity = new Vector3 (0, speed, 0);
	}

}

