﻿using UnityEngine;
using System.Collections;

public class KillingCounter : MonoBehaviour {
	public static int score =0;

	// Update is called once per frame
	void Update () {
		//scorescore = enemy.kill_count;
	}
	void OnGUI() {
		GUI.Label(new Rect(Screen.width - 50, 10, 100, 200), "Score: "+ (score/3).ToString());
	}
}
