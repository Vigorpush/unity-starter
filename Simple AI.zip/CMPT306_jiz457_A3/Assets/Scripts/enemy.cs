﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class enemy : MonoBehaviour {

	public AudioClip deathSound;
	public AudioSource audio;
	public GameObject explosion;


    public int startingHealth = 100;//add HP into enermy
    public static int currentHealth;


    public static bool islowHP = false;//check the low HP
    bool isDead;
    bool damaged;
    public Slider healthslider;

    /*
    float[] distancefriend;//find the friends
    public float nearcheck = 5;


    public float Maxdistancetohome = 20;
    public Transform home;//the home location


    public float maxrangetoplayer = 20;
    public float maxThreatzone = 100;
     * */
    void Awake(){
		audio = GetComponent <AudioSource> ();
        currentHealth = startingHealth;
	}


    void Start()
    {
        //home = gameObject.transform;
    }


	void OnTriggerEnter (Collider other){

		if (other.tag == "Player") {
			Debug.Log ("Player Dead!");

			Application.LoadLevel("Main");
			KillingCounter.score = 0;
			Destroy (gameObject);
			audio.PlayOneShot (deathSound,1f);

		}
		if(other.tag=="shot"){

			audio.PlayOneShot (deathSound,1f);
            Destroy(other);
            takedamage(20);
			KillingCounter.score++;

		}
		if (other.tag == "Enemy") {
			
		}
	}




    public void takedamage(int amount)
    {
        damaged = true;

        currentHealth -= amount;

       // lowHP();

       // healthslider.value = currentHealth;

        if( currentHealth <= 0 && !isDead){

            Destroy(gameObject);
            
            Instantiate(explosion, transform.position, transform.rotation);
        }

    }

}
