﻿using UnityEngine;
using System.Collections;

public class AI : MonoBehaviour {
	public Transform target;
	public float speed;
	public float realtime;

	private Transform mytransform;
	// Use this for initialization
	void Awake(){
		mytransform = transform;
	}


	void Start () {
		GameObject pl = GameObject.FindGameObjectWithTag ("Player");
		target = pl.transform;
	}

	// Update is called once per frame
	void FixedUpdate () {
		//Vector3 playerposition = new Vector3 (target.position.x, target.position.y,0.0f);
		//mytransform.transform.Translate (Mathf.Clamp (speed * Time.deltaTime, 0, realtime * Time.deltaTime), Mathf.Clamp (speed * Time.deltaTime, 0, realtime * Time.deltaTime), 0f);
		Vector3 pos = transform.position;
		pos.x = Mathf.MoveTowards(pos.x, target.position.x, Time.deltaTime * speed);
		pos.y = Mathf.MoveTowards(pos.y, target.position.y, Time.deltaTime * speed);
		transform.position = pos;
	}



}
