﻿using UnityEngine;
using System.Collections;

public class enemy : MonoBehaviour {

	public AudioClip deathSound;
	public AudioSource audio;
	public GameObject explosion;

	void Awake(){
		audio = GetComponent <AudioSource> ();
	}

	void OnTriggerEnter (Collider other){

		if (other.tag == "Player") {
			Debug.Log ("Player Dead!");

			Application.LoadLevel("Main");
			KillingCounter.score = 0;
			Destroy (gameObject);
			audio.PlayOneShot (deathSound,1f);

		}
		if(other.tag=="shot"){

			audio.PlayOneShot (deathSound,1f);
			Destroy (gameObject);
			Destroy (other);
			Instantiate (explosion, transform.position, transform.rotation);
			KillingCounter.score++;

		}
		if (other.tag == "Enemy") {
			Debug.Log ("Hello, Emoji");
		}
	}
}
