﻿using UnityEngine;
using System.Collections;

public class bouncing_pad : MonoBehaviour {

    public Rigidbody2D player ;

    void OnCollisionEnter2D(Collision2D coll)
    {
        // If the Collider2D component is enabled on the object we collided with
        if (coll.collider == true)
        {
            player.transform.Translate(Vector3.up * 50 * Time.deltaTime, Space.World);   
        }
    }
}



