﻿using UnityEngine;
using System.Collections;

public class moving_floor : MonoBehaviour {

    public float speed;
    Vector2 floatx;
    public GameObject game_obj;
    //private Rigidbody2D rb;
    public float floatStrength = 1;
    float originalx;
	// Use this for initialization
	void Start () {
        //game_obj = GetComponent<GameObject>();
        originalx = game_obj.transform.position.x;
	}

    void FixedUpdate(){
        transform.position = new Vector2( originalx + (Mathf.Cos(Time.time) * floatStrength),transform.position.y);
    }
}
