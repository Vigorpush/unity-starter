﻿using UnityEngine;
using System.Collections;

public class dis_appear : MonoBehaviour {
    // make the object invisible 
    public GameObject game_obj;
    public float Speed;
	// Use this for initialization
	void Start () {
        InvokeRepeating("DisappearanceLogic", 0, Speed);
	}

    //function for DisappearanceLogic
    void DisappearanceLogic()
    {
        if (game_obj.activeSelf)
        {
            game_obj.SetActive(false);
        }
        else
        {
            game_obj.SetActive(true);
        }
    }
}
