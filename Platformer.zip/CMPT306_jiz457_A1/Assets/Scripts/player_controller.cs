﻿using UnityEngine;
using System.Collections;

public class player_controller : MonoBehaviour
{

    public float walkSpeed = 1;
    private bool _isGrounded = true;
    public float jump = 100f;
    Animator animator;
    bool _is_Playing_goleft = false;
    bool _is_Playing_jumping = false;



    const int STATE_GORIGHT_STANDING = 0;
    const int STATE_GOLEFT = 1;
    const int STATE_JUMPING = 2;
    const int STATE_ATTACKING = 3;
    private Rigidbody2D rb;

    string _currentDirection = "left";
    int _currentAnimationState = STATE_GORIGHT_STANDING;

    void Start()
    {
        animator = this.GetComponent<Animator>();
        rb = this.GetComponent<Rigidbody2D>(); 
    }


    void update()
    {
        
    }

    void FixedUpdate()
    {
        //Check for keyboard input
       
        if (!_isGrounded && rb.velocity.y == 0)
        {
            _isGrounded = true;
        }
        if ((Input.GetKeyUp("up")) && (_isGrounded = true))
        {
            //changeState(STATE_GORIGHT_STANDING);

            changeState(STATE_JUMPING);

            rb.AddForce(transform.up * jump);
            transform.Translate(Vector3.up * 250 * Time.deltaTime, Space.World);

            _isGrounded = false;
            //changeState(STATE_GORIGHT_STANDING);

        }
     

        if (Input.GetKey("right")  && !_is_Playing_jumping)
        {
            transform.Translate(Input.GetAxis("Horizontal") * 3f * Time.deltaTime, 0f, 0f);

            if (_isGrounded)
                changeState(STATE_GORIGHT_STANDING);

        }
        else if (Input.GetKey("left")  )
        {
            transform.Translate(Input.GetAxis("Horizontal") * 3f * Time.deltaTime, 0f, 0f);

            if (_isGrounded)
                changeState(STATE_GOLEFT);
        }
        else
        {
            if (_isGrounded)
                changeState(STATE_GORIGHT_STANDING);
        }

        //check if goleft animation is playing
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("goleft"))
            _is_Playing_goleft = true;
        else
            _is_Playing_goleft = false;

        //check if jumping animation is playing
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("jumping"))
            _is_Playing_jumping = true;
        else
            _is_Playing_jumping = false;


        
    }

    void changeState(int state)
    {

        if (_currentAnimationState == state)
            return;

        switch (state)
        {

            case STATE_GORIGHT_STANDING:
                animator.SetInteger("state", STATE_GORIGHT_STANDING);
                break;

            case STATE_GOLEFT:
                animator.SetInteger("state", STATE_GOLEFT);
                break;

            case STATE_JUMPING:
                animator.SetInteger("state", STATE_JUMPING);
                break;


        }

        _currentAnimationState = state;
    }

    //--------------------------------------
    // Check if player has collided with the floor
    //--------------------------------------
    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.name == "ground")
        {
            _isGrounded = true;
            changeState(STATE_GORIGHT_STANDING);
            Debug.Log("Ground it");
        }
    }

    //--------------------------------------
    // Flip player sprite for left/right walking
    //--------------------------------------
    void changeDirection(string direction)
    {

        if (_currentDirection != direction)
        {
            if (direction == "right")
            {
                transform.Rotate(0, 180, 0);
                _currentDirection = "right";
            }
            else if (direction == "left")
            {
                transform.Rotate(0, -180, 0);
                _currentDirection = "left";
            }
        }

    }
}
