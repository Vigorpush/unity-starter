﻿using UnityEngine;
using System.Collections;

public class player_die : MonoBehaviour {

    private float death_height = -5;
    public GameObject game_obj;
	// Update is called once per frame
	void Update () {
	    if(transform.position.y<=death_height){
            Application.LoadLevel("main");
        }
	}
}
